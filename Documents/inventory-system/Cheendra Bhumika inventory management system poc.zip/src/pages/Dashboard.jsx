
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Stack,
  Chip,
  Avatar,
  Divider,
} from '@mui/material'

import Inventory2Outlined from '@mui/icons-material/Inventory2Outlined'
import StorageOutlined from '@mui/icons-material/StorageOutlined'
import WarningAmberOutlined from '@mui/icons-material/WarningAmberOutlined'
import RemoveShoppingCartOutlined from '@mui/icons-material/RemoveShoppingCartOutlined'
import CurrencyRupeeOutlined from '@mui/icons-material/CurrencyRupeeOutlined'
import ReceiptLongOutlined from '@mui/icons-material/ReceiptLongOutlined'
import VisibilityOutlined from '@mui/icons-material/VisibilityOutlined'
import MoveToInboxOutlined from '@mui/icons-material/MoveToInboxOutlined'
import TrendingUpOutlined from '@mui/icons-material/TrendingUpOutlined'
import InventoryOutlined from '@mui/icons-material/InventoryOutlined'

import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

import ActionIcon from '../components/common/ActionIcon'
import StockStatusChip from '../components/common/StockStatusChip'

import { getProducts } from '../services/productService'
import { getCategories } from '../services/categoryService'
import { getTransactions } from '../services/transactionService'

import { buildProductsWithStock } from '../utils/inventoryUtils'
import { formatMoney, toDateKey } from '../utils/formatters'

function Dashboard() {
  const navigate = useNavigate()

  const [products] = useState(() => getProducts())
  const [categories] = useState(() => getCategories())
  const [transactions] = useState(() => getTransactions())

  // Calculate active products and available stock.
  const activeProducts = buildProductsWithStock(
    products,
    transactions
  ).filter((product) => product.status === 'Active')

  const totalUnits = activeProducts.reduce(
    (sum, product) => sum + product.availableStock,
    0
  )

  const inventoryValue = activeProducts.reduce(
    (sum, product) => sum + product.inventoryValue,
    0
  )

  const lowStockCount = activeProducts.filter(
    (product) => product.stockStatus === 'Low Stock'
  ).length

  const outOfStockCount = activeProducts.filter(
    (product) => product.stockStatus === 'Out of Stock'
  ).length

  // Calculate today's transactions.
  const todayKey = toDateKey(new Date().toISOString())

  const todayTransactions = transactions.filter(
    (transaction) =>
      transaction.type !== 'Opening' &&
      toDateKey(transaction.date) === todayKey
  )

  const receipts = todayTransactions.filter(
    (transaction) => transaction.type === 'Stock In'
  ).length

  const issues = todayTransactions.filter(
    (transaction) => transaction.type === 'Stock Out'
  ).length

  const adjustments = todayTransactions.filter(
    (transaction) => transaction.type === 'Adjustment'
  ).length

  // Calculate stock by category.
  const stockByCategory = categories.map((category) => ({
    category: category.name,
    stock: activeProducts
      .filter((product) => product.categoryId === category.id)
      .reduce(
        (sum, product) => sum + product.availableStock,
        0
      ),
  }))

  // Find products requiring replenishment.
  const replenishment = activeProducts
    .filter((product) => product.stockStatus !== 'In Stock')
    .sort((a, b) => b.shortfall - a.shortfall)

  // Dashboard statistics.
  const statistics = [
    {
      title: 'Total Products',
      value: activeProducts.length,
      subtitle: 'Active products',
      icon: Inventory2Outlined,
      color: '#2563EB',
      background: '#EFF6FF',
    },
    {
      title: 'Total Stock Units',
      value: totalUnits.toLocaleString('en-IN'),
      subtitle: 'Available inventory',
      icon: StorageOutlined,
      color: '#059669',
      background: '#ECFDF5',
    },
    {
      title: 'Low Stock Products',
      value: lowStockCount,
      subtitle: 'Need replenishment',
      icon: WarningAmberOutlined,
      color: '#D97706',
      background: '#FFFBEB',
    },
    {
      title: 'Out of Stock',
      value: outOfStockCount,
      subtitle: 'Products unavailable',
      icon: RemoveShoppingCartOutlined,
      color: '#DC2626',
      background: '#FEF2F2',
    },
    {
      title: 'Inventory Value',
      value: formatMoney(inventoryValue),
      subtitle: 'Current stock value',
      icon: CurrencyRupeeOutlined,
      color: '#7C3AED',
      background: '#F5F3FF',
    },
    {
      title: "Today's Transactions",
      value: todayTransactions.length,
      subtitle: `In: ${receipts} | Out: ${issues} | Adjustments: ${adjustments}`,
      icon: ReceiptLongOutlined,
      color: '#0891B2',
      background: '#ECFEFF',
    },
  ]

  const cardStyle = {
    border: '1px solid #E2E8F0',
    borderRadius: 3,
    boxShadow: '0 2px 8px rgba(15, 23, 42, 0.04)',
    backgroundColor: '#FFFFFF',
  }

  return (
    <Box sx={{ width: '100%', pb: 3 }}>

      {/* WELCOME BANNER */}
      <Paper
        elevation={0}
        sx={{
          mb: 3,
          p: { xs: 2.5, md: 3.5 },
          borderRadius: 3,
          color: '#FFFFFF',
          background:
            'linear-gradient(115deg, #102A50 0%, #17477D 65%, #2563A6 100%)',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            width: 180,
            height: 180,
            borderRadius: '50%',
            background: 'rgba(255,255,255,0.05)',
            right: -30,
            top: -90,
          }}
        />

        <Stack direction="row" alignItems="center" spacing={2}>
          <Avatar
            variant="rounded"
            sx={{
              width: 65,
              height: 65,
              bgcolor: 'rgba(255,255,255,0.14)',
              color: '#FFFFFF',
              border: '1px solid rgba(255,255,255,0.25)',
            }}
          >
            <InventoryOutlined sx={{ fontSize: 36 }} />
          </Avatar>

          <Box>
            <Typography
              variant="h4"
              sx={{
                color: '#FFFFFF',
                fontWeight: 800,
                fontSize: { xs: 22, md: 30 },
                letterSpacing: '-0.5px',
              }}
            >
              Inventory Management System
            </Typography>

            <Typography
              sx={{
                mt: 0.7,
                color: '#DCEBFA',
                fontSize: 14,
              }}
            >
              Monitor your inventory and manage stock efficiently.
            </Typography>
          </Box>
        </Stack>

        <Stack
          direction="row"
          alignItems="center"
          spacing={1}
          sx={{ mt: 2.5 }}
        >
          <TrendingUpOutlined sx={{ color: '#7DD3FC' }} />

          <Typography sx={{ color: '#DCEBFA', fontSize: 12 }}>
            Inventory overview and stock performance
          </Typography>
        </Stack>
      </Paper>

      {/* STATISTICS CARDS */}
      <Box
        sx={{
          display: 'grid',
          gridTemplateColumns: {
            xs: '1fr',
            sm: 'repeat(2, 1fr)',
            lg: 'repeat(3, 1fr)',
          },
          gap: 2,
          mb: 3,
        }}
      >
        {statistics.map((item) => {
          const Icon = item.icon

          return (
            <Paper
              key={item.title}
              elevation={0}
              sx={{
                ...cardStyle,
                p: 2.2,
                transition: 'all 0.25s ease',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: '0 8px 20px rgba(15,23,42,0.09)',
                },
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >
                <Box sx={{ minWidth: 0 }}>
                  <Typography
                    sx={{
                      color: '#64748B',
                      fontSize: 12,
                      fontWeight: 700,
                      textTransform: 'uppercase',
                      letterSpacing: 0.5,
                    }}
                  >
                    {item.title}
                  </Typography>

                  <Typography
                    sx={{
                      mt: 1,
                      color: '#102A50',
                      fontWeight: 800,
                      fontSize: {
                        xs: 23,
                        md: item.title === 'Inventory Value' ? 21 : 29,
                      },
                      overflowWrap: 'anywhere',
                    }}
                  >
                    {item.value}
                  </Typography>

                  <Typography
                    sx={{
                      mt: 0.7,
                      color: '#94A3B8',
                      fontSize: 11,
                    }}
                  >
                    {item.subtitle}
                  </Typography>
                </Box>

                <Avatar
                  variant="rounded"
                  sx={{
                    width: 49,
                    height: 49,
                    bgcolor: item.background,
                    color: item.color,
                    flexShrink: 0,
                  }}
                >
                  <Icon sx={{ fontSize: 27 }} />
                </Avatar>
              </Stack>

              <Box
                sx={{
                  mt: 2,
                  height: 3,
                  borderRadius: 5,
                  bgcolor: item.background,
                }}
              >
                <Box
                  sx={{
                    width: '65%',
                    height: '100%',
                    borderRadius: 5,
                    bgcolor: item.color,
                  }}
                />
              </Box>
            </Paper>
          )
        })}
      </Box>

      {/* STOCK BY CATEGORY CHART */}
      <Paper
        elevation={0}
        sx={{
          ...cardStyle,
          p: { xs: 2, md: 2.5 },
          mb: 3,
        }}
      >
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          sx={{ mb: 2 }}
        >
          <Box>
            <Typography
              variant="h6"
              sx={{ color: '#102A50', fontWeight: 800 }}
            >
              Stock by Category
            </Typography>

            <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>
              Available inventory across product categories
            </Typography>
          </Box>

          <Chip
            label="Current Stock"
            size="small"
            sx={{
              bgcolor: '#EFF6FF',
              color: '#1D4ED8',
              fontWeight: 700,
            }}
          />
        </Stack>

        <Divider sx={{ mb: 2, borderColor: '#EDF1F7' }} />

        <Box sx={{ width: '100%', height: 310 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={stockByCategory}
              margin={{ top: 10, right: 15, left: 5, bottom: 15 }}
            >
              <CartesianGrid
                strokeDasharray="4 4"
                vertical={false}
                stroke="#E8EDF5"
              />

              <XAxis
                dataKey="category"
                tick={{ fill: '#64748B', fontSize: 11 }}
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />

              <YAxis
                allowDecimals={false}
                tick={{ fill: '#64748B', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />

              <Tooltip
                contentStyle={{
                  borderRadius: 10,
                  border: '1px solid #E2E8F0',
                  boxShadow: '0 4px 15px rgba(0,0,0,0.08)',
                }}
                cursor={{ fill: '#F1F5F9' }}
              />

              <Bar
                dataKey="stock"
                name="Units in stock"
                fill="#1E4F85"
                radius={[6, 6, 0, 0]}
                maxBarSize={65}
              />
            </BarChart>
          </ResponsiveContainer>
        </Box>
      </Paper>

      {/* REPLENISHMENT TABLE */}
      <Paper
        elevation={0}
        sx={{
          ...cardStyle,
          overflow: 'hidden',
        }}
      >
        <Box sx={{ p: 2.5 }}>
          <Stack
            direction={{ xs: 'column', sm: 'row' }}
            justifyContent="space-between"
            alignItems={{ xs: 'flex-start', sm: 'center' }}
            spacing={1}
          >
            <Box>
              <Typography
                variant="h6"
                sx={{ color: '#102A50', fontWeight: 800 }}
              >
                Products Needing Replenishment
              </Typography>

              <Typography sx={{ fontSize: 12, color: '#94A3B8' }}>
                Products that require stock attention
              </Typography>
            </Box>

            <Chip
              label={`${replenishment.length} Products`}
              color={replenishment.length > 0 ? 'warning' : 'success'}
              size="small"
              sx={{ fontWeight: 700 }}
            />
          </Stack>
        </Box>

        <Divider sx={{ borderColor: '#EDF1F7' }} />

        <TableContainer>
          <Table size="medium">
            <TableHead>
              <TableRow sx={{ bgcolor: '#F1F5F9' }}>
                {[
                  'Product',
                  'Available',
                  'Reorder Level',
                  'Shortfall',
                  'Status',
                  'Actions',
                ].map((heading, index) => (
                  <TableCell
                    key={heading}
                    align={index === 0 ? 'left' : 'center'}
                    sx={{
                      color: '#334155',
                      fontSize: 11,
                      fontWeight: 800,
                      whiteSpace: 'nowrap',
                      py: 1.5,
                    }}
                  >
                    {heading}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {replenishment.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} align="center" sx={{ py: 5 }}>
                    <Typography
                      sx={{ color: '#059669', fontWeight: 700 }}
                    >
                      All products have sufficient stock.
                    </Typography>
                  </TableCell>
                </TableRow>
              )}

              {replenishment.map((product) => (
                <TableRow
                  key={product.id}
                  hover
                  sx={{
                    '&:last-child td': { borderBottom: 0 },
                    '&:hover': { bgcolor: '#F8FAFC' },
                  }}
                >
                  <TableCell sx={{ minWidth: 180 }}>
                    <Typography
                      sx={{
                        fontWeight: 700,
                        fontSize: 12,
                        color: '#1E293B',
                      }}
                    >
                      {product.name}
                    </Typography>

                    <Typography
                      sx={{
                        fontSize: 10,
                        color: '#94A3B8',
                        mt: 0.3,
                      }}
                    >
                      {product.code}
                    </Typography>
                  </TableCell>

                  <TableCell
                    align="center"
                    sx={{ fontWeight: 700, color: '#1E293B' }}
                  >
                    {product.availableStock}
                  </TableCell>

                  <TableCell align="center">
                    {product.reorderLevel}
                  </TableCell>

                  <TableCell
                    align="center"
                    sx={{
                      color: '#DC2626',
                      fontWeight: 700,
                    }}
                  >
                    {product.shortfall}
                  </TableCell>

                  <TableCell align="center">
                    <StockStatusChip status={product.stockStatus} />
                  </TableCell>

                  <TableCell align="center">
                    <Stack
                      direction="row"
                      justifyContent="center"
                      spacing={0.5}
                    >
                      <ActionIcon
                        title="View Product"
                        icon={VisibilityOutlined}
                        color="primary"
                        onClick={() =>
                          navigate(`/products/${product.id}`)
                        }
                      />

                      <ActionIcon
                        title="Receive Stock"
                        icon={MoveToInboxOutlined}
                        color="primary"
                        onClick={() => navigate('/stock-in')}
                      />
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        <Divider sx={{ borderColor: '#EDF1F7' }} />

        <Box
          sx={{
            px: 2.5,
            py: 1.5,
            bgcolor: '#FAFCFF',
          }}
        >
          <Typography sx={{ color: '#94A3B8', fontSize: 11 }}>
            Inventory Management System | Stock overview
          </Typography>
        </Box>
      </Paper>
    </Box>
  )
}

export default Dashboard
